@javax.xml.bind.annotation.XmlSchema(namespace = "http://study03.ch01/")
package ch01.study03.client;
