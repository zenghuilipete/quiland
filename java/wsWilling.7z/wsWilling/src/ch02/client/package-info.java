@javax.xml.bind.annotation.XmlSchema(namespace = "http://tsd.ch02/")
package ch02.client;
