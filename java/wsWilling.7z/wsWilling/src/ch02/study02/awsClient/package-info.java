@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservices.amazon.com/AWSECommerceService/2011-08-01", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package awsClient;
