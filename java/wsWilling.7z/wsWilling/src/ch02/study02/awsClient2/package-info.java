@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservices.amazon.com/AWSECommerceService/2008-10-06", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ch02.study02.awsClient2;
