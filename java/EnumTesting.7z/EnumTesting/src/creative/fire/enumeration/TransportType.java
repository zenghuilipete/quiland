package creative.fire.enumeration;

public enum TransportType {
	TCP(0), UDP(1), TLS(2);

	private int value;

	TransportType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public static TransportType getInstance(int transportType) {
		switch (transportType) {
		case 0:
			return TransportType.TCP;
		case 1:
			return TransportType.UDP;
		case 2:
			return TransportType.TLS;
		default:
			return TransportType.TCP;
		}
	}
}