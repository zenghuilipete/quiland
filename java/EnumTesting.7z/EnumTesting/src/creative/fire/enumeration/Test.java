package creative.fire.enumeration;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name = RecorderStatus.ERC_CONFERENCE_IS_BEING_RECORDED.name();
		String s = RecorderStatus.ERC_CONFERENCE_IS_BEING_RECORDED.toString();
		System.out.println(name);
		System.out.println(s);

		System.out.println(TransportType.TLS.name());
		System.out.println(TransportType.TLS.toString());
		System.out.println(TransportType.TLS.ordinal());
		System.out.println(TransportType.TLS.getValue());
	}

}
