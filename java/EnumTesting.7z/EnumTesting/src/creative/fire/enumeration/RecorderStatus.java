package creative.fire.enumeration;

/**
 * Recording Status Request From Scopia Desktop Server
 * 
 * @since version7.7
 * @author luh 2011.6.24
 */
public enum RecorderStatus {
	RECORDING_STARTED, // Started successfully

	RECORDING_FINISHED, // Finished successfully

	ERC_INTERNAL_ERROR, // Undefined internal error

	ERC_RECORDER_IS_DOWN, // Recorder is not reachable

	ERC_NO_RECORDING_LICENSE, // No recording license

	ERC_NOT_ENOUGH_DISK_SPACE, // There is not enough disk space to start new recording

	ERC_STORAGE_CAPACITY_LIMIT_REACHED, // The storage capacity limit has been reached

	ERC_RECORDINGS_IN_PROGRESS_LIMIT_REACHED, // Too many recordings in progress

	ERC_NO_CONFERENCE_PORTS_AVAILABLE, // No MCU conference ports are available to start new recording

	ERC_INVALID_CONFERENCE_ID, // Cannot access MCU conference -invalid conference ID

	ERC_INVALID_CONFERENCE_PASSWORD, // Cannot access MCU conference incorrect password

	ERC_CONFERENCE_IS_LOCKED, // Cannot access MCU conference -conference is locked

	ERC_RECORDING_IS_ALREADY_IN_PROGRESS, // Meeting is already being recorded

	ERC_MAX_DURATION_REACHED,// Max recording duration has been reached
	
	ERC_RECORDING_ABLITY_LOST,//No Sdg...
	
	ERC_CONFERENCE_IS_BEING_RECORDED;
}