package study;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.btree.parameter.DuplicatedKeyException;

public class Base{
	static boolean show = true;
	static int degree = 2;
	static int loop = 30;
	static int random = 100;
	static int seed = 10;

	static void buildTree(IBTree tree) {
		Random r = new Random(seed);
		long begin = System.currentTimeMillis();
		for (int i = 1; i <= loop; i++) {
			int number = r.nextInt(random);
			// int number = i;
			try {
				tree.insert(number, number + "@");
				if (show) {
					System.out.print(number + "\t");
					if (i % 10 == 0) {
						System.out.print("\n");
					}
				}
			} catch (DuplicatedKeyException e) {
				i--;
				continue;
			}
		}
		long end = System.currentTimeMillis();
		long elapsed = end - begin;
		System.out.print("\nnode count=" + loop + " elapsed:" + elapsed + " 毫秒\n");
	}

	static void showTree(IBTree tree) {
		System.out.println("树结=" + tree.getHeight());
		System.out.println("树阶=" + tree.getDegree());
		System.out.println("结点数=" + tree.getSize());
//		System.out.println("最小值=" + tree.getSmallest(tree.getRoot(), false));
//		System.out.println("最大值=" + tree.getBiggest(tree.getRoot(), false));
		List<INode> list = new ArrayList<INode>(1);
		list.add(tree.getRoot());
		List<INode> breadthNodes = tree.iterator().retrieveByBreadth(list);
		if (show) {
			System.out.println("广度遍历:");
			for (INode iNode : breadthNodes) {
				System.out.println(iNode.getInfo());
			}
			/*
			List<INode> depthNodes = tree.iterator().retrieveByDepth(tree.getRoot());
			System.out.println("深度遍历:");
			for (INode iNode : depthNodes) {
				System.out.println(iNode.getInfo());
			}
			*/
		}
	}
}
