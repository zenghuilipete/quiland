package study;

import ojadb.core.btree.IBTree;
import ojadb.core.ojadbtree.OjadbSingleValueBTree;

public class Test {
	private static boolean show;

	public static void main(String[] args) {
		show = true;
		int degree = 3;
		IBTree tree = new OjadbSingleValueBTree("testTree", degree);
		buildTree(tree);
		Base.showTree(tree);
		tree.delete('X', 88);
		Base.showTree(tree);
	}

	static void buildTree(IBTree tree) {
		for (int i = 65; i <= 88; i++) {
			if (i == 79 || i == 81 || i == 86 || i == 87)
				continue;
			char c = (char) i;
			tree.insert(c, i);
			if (show) {
				System.out.print(c + "\t");
			}
		}
		System.out.print("\n");
	}
}
