package study;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.ojadbtree.OjadbSingleValueBTree;

public class Step{
	private static final int loop = 30;

	public static void main(String[] args) {
		IBTree tree = new OjadbSingleValueBTree("testTree", 2);
		buildTree(tree);
	}

	private static void showTree(IBTree tree) {
		List<INode> list = new ArrayList<INode>(1);
		list.add(tree.getRoot());
		List<INode> breadthNodes = tree.iterator().retrieveByBreadth(list);
		System.out.println("----");
		for (INode iNode : breadthNodes) {
			System.out.println(iNode.getInfo());
		}
		System.out.println("----");
	}

	private static void buildTree(IBTree tree) {
		HashSet<Integer> set = new HashSet<Integer>();
		Random r = new Random(10);
		for (int i = 1; i <= loop; i++) {
			int number = r.nextInt(100);
			while (set.contains(number))
				number = r.nextInt(100);
			set.add(number);
			tree.insert(number, "@" + number + "@");
			System.out.println("\n<" + i + "> " + number + ":");
			showTree(tree);
		}
	}
}
