/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.ojadbtree;

import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.btree.impl.singlevalue.SingleValueNode;
import ojadb.core.btree.parameter.BTreeException;

public class OjadbSingleNode extends SingleValueNode {
	private static final long serialVersionUID = -8962846205438051518L;

	public OjadbSingleNode() {
		super();
	}

	protected INode parentNode;
	/** lazy loaded */
	protected transient INode parent;

	public OjadbSingleNode(IBTree btree) {
		super(btree);
		nodeId = nextId.incrementAndGet();
	}

	public INode getChildAt(int index, boolean throwExceptionIfNotExist) {
		INode node = childrenNodes[index];
		if (nodeId == null) {
			if (throwExceptionIfNotExist) {
				throw new BTreeException("第" + index + "个子结点为空");
			}
			return null;
		}
		return node;
	}

	public String getInfo() {
		StringBuilder buffer = new StringBuilder();

		if (height > -1)
			buffer.append("[" + height + "]");

		buffer.append("id=").append(getId()).append("\t" + currentKeyCount + "_keys: {");
		for (int i = 0; i < currentKeyCount; i++) {
			if (i > 0) {
				buffer.append(",");
			}
			buffer.append(keys[i]);
		}
		buffer.append("}\t" + currentChildrenCount + "_children: {");
		for (int i = 0; i < currentChildrenCount; i++) {
			if (i > 0) {
				buffer.append(",");
			}
			buffer.append(childrenNodes[i].getId());
		}
		buffer.append("} ");
		return buffer.toString();
	}

	public void setChildAt(INode child, int index) {
		if (child != null) {
			childrenNodes[index] = child;
			child.setParent(this);
		} else {
			childrenNodes[index] = null;
		}
	}

	protected void init() {
		childrenNodes = new INode[maxChildrenCount];
		parentNode = null;
		parent = null;
	}

	public Long getId() {
		return nodeId;
	}

	public void setId(Long id) {
		this.nodeId = id;
	}

	public void clear() {
		super.clear();
		parent = null;
		parentNode = null;
		childrenNodes = null;
		nodeId = null;
	}

	public void deleteChildAt(int index) {
		childrenNodes[index] = null;
		currentChildrenCount--;
	}

	public void moveChildFromTo(int sourceIndex, int destinationIndex, boolean throwExceptionIfDoesNotExist) {
		if (throwExceptionIfDoesNotExist && childrenNodes[sourceIndex] == null) {
			throw new BTreeException("试图加载空子结点 " + sourceIndex);
		}
		childrenNodes[destinationIndex] = childrenNodes[sourceIndex];
	}

	public void setChildAt(INode node, int childIndex, int indexDestination, boolean throwExceptionIfDoesNotExist) {
		INode childOid = (INode) node.getChildIdAt(childIndex, throwExceptionIfDoesNotExist);
		childrenNodes[indexDestination] = childOid;
	}

	public void setNullChildAt(int childIndex) {
		childrenNodes[childIndex] = null;
	}

	public Object getChildIdAt(int childIndex, boolean throwExceptionIfDoesNotExist) {
		if (throwExceptionIfDoesNotExist && childrenNodes[childIndex] == null) {
			throw new BTreeException("试图加载空子结点 " + childIndex);
		}
		return childrenNodes[childIndex];
	}

	public Long getParentId() {
		return parentNode.getId();
	}

	public Object getValueAsObjectAt(int index) {
		return getValueAt(index);
	}
}
