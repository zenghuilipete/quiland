/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.ojadbtree;

import ojadb.core.btree.INode;
import ojadb.core.btree.impl.multiplevalue.MultipleValueBTree;

public class OjadbMultipleValueBTree extends MultipleValueBTree {
	private static final long serialVersionUID = 8997343388175066101L;
	protected static int nextId = 1;
	protected Long oid;

	public OjadbMultipleValueBTree() {
		super();
		oid = System.currentTimeMillis() + new Long(nextId++);
	}

	public OjadbMultipleValueBTree(String name, int degree) {
		super(name, degree);
		oid = System.currentTimeMillis() + new Long(nextId++);
	}

	public INode buildNode() {
		OjadbMultipleValueNode node = new OjadbMultipleValueNode(this);
		return node;
	}

	public Long getId() {
		return oid;
	}

	public void setId(Long id) {
		this.oid = id;
	}
}
