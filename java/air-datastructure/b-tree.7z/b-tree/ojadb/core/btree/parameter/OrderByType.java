/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.parameter;

import java.io.Serializable;

public class OrderByType implements Serializable {
	private static final long serialVersionUID = 1820032677588644360L;
	private static final int ORDER_BY_NONE_TYPE = 0;
	private static final int ORDER_BY_DESC_TYPE = 1;
	private static final int ORDER_BY_ASC_TYPE = 2;
	public static final OrderByType ORDER_BY_NONE = new OrderByType(ORDER_BY_NONE_TYPE);
	public static final OrderByType ORDER_BY_DESC = new OrderByType(ORDER_BY_DESC_TYPE);
	public static final OrderByType ORDER_BY_ASC = new OrderByType(ORDER_BY_ASC_TYPE);
	private int type;

	private OrderByType(int type) {
		this.type = type;
	}

	public boolean isOrderByDesc() {
		return type == ORDER_BY_DESC_TYPE;
	}

	public boolean isOrderByAsc() {
		return type == ORDER_BY_ASC_TYPE;
	}

	public boolean isOrderByNone() {
		return type == ORDER_BY_NONE_TYPE;
	}

	public String toString() {
		switch (type) {
		case ORDER_BY_ASC_TYPE:
			return "order by asc";
		case ORDER_BY_DESC_TYPE:
			return "order by desc";
		case ORDER_BY_NONE_TYPE:
			return "no order by";
		}
		return "?";
	}
}
