/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.iterator;

import java.util.Iterator;
import java.util.List;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.btree.parameter.OrderByType;

public abstract class BTreeIterator implements Iterator{
	private IBTree btree;
	protected INode currentNode;
	private int currentKeyIndex;
	private int nbReturnedKeys;
	protected int nbReturnedElements;
	private OrderByType orderByType;

	public BTreeIterator(IBTree tree, OrderByType orderByType) {
		this.btree = tree;
		this.currentNode = tree.getRoot();
		this.orderByType = orderByType;
		if (orderByType.isOrderByDesc()) {
			this.currentKeyIndex = currentNode.getKeysCount();
		} else {
			this.currentKeyIndex = 0;
		}
	}

	public abstract Object getValueAt(INode node, int currentIndex);

	public boolean hasNext() {
		return nbReturnedElements < btree.getSize();
	}

	public Object next() {
		if (currentKeyIndex > currentNode.getKeysCount() || nbReturnedElements >= btree.getSize()) {
			//
		}
		if (orderByType.isOrderByDesc()) {
			return nextDesc();
		}
		return nextAsc();
	}

	protected Object nextAsc() {
		while (!currentNode.isLeaf()) {
			currentNode = currentNode.getChildAt(currentKeyIndex, true);
			currentKeyIndex = 0;
		}
		if (currentKeyIndex < currentNode.getKeysCount()) {
			nbReturnedKeys++;
			nbReturnedElements++;
			Object nodeValue = getValueAt(currentNode, currentKeyIndex);
			currentKeyIndex++;
			return nodeValue;
		}
		INode child = null;
		while (currentKeyIndex >= currentNode.getKeysCount()) {
			child = currentNode;
			currentNode = currentNode.getParent();
			currentKeyIndex = indexOfChild(currentNode, child);
		}
		nbReturnedElements++;
		nbReturnedKeys++;
		Object value = getValueAt(currentNode, currentKeyIndex);
		currentKeyIndex++;
		return value;
	}

	protected Object nextDesc() {
		while (!currentNode.isLeaf()) {
			currentNode = currentNode.getChildAt(currentKeyIndex, true);
			currentKeyIndex = currentNode.getKeysCount();
		}
		if (currentKeyIndex > 0) {
			nbReturnedElements++;
			nbReturnedKeys++;
			currentKeyIndex--;
			Object nodeValue = getValueAt(currentNode, currentKeyIndex);
			return nodeValue;
		}
		INode child = null;
		while (currentKeyIndex == 0) {
			child = currentNode;
			currentNode = currentNode.getParent();
			currentKeyIndex = indexOfChild(currentNode, child);
		}
		nbReturnedElements++;
		nbReturnedKeys++;
		currentKeyIndex--;
		Object value = getValueAt(currentNode, currentKeyIndex);
		return value;
	}

	private int indexOfChild(INode parent, INode child) {
		for (int i = 0; i < parent.getChildrenCount(); i++) {
			if (parent.getChildAt(i, true).getId() == child.getId()) {
				return i;
			}
		}
		throw new RuntimeException("父结点 " + parent + " 没有子结点 : " + child);
	}

	public void remove() {}

	public void reset() {
		this.currentNode = btree.getRoot();
		if (orderByType.isOrderByDesc()) {
			this.currentKeyIndex = currentNode.getKeysCount();
		} else {
			this.currentKeyIndex = 0;
		}
		nbReturnedElements = 0;
		nbReturnedKeys = 0;
	}

	public abstract List<INode> retrieveByDepth(INode binNode);

	public abstract List<INode> retrieveByBreadth(List<INode> allChindNodes);
}
