/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.iterator;

import java.util.List;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.btree.parameter.OrderByType;

public class MultipleValueBTreeIterator extends BTreeIterator {
	public MultipleValueBTreeIterator(IBTree tree, OrderByType orderByType) {
		super(tree, orderByType);
		currenListIndex = 0;
		currentValue = null;
	}

	private int currenListIndex;
	private List currentValue;

	public Object next() {
		if (currentNode != null && currentValue != null) {
			int listSize = currentValue.size();
			if (listSize > currenListIndex) {
				Object value = currentValue.get(currenListIndex);
				currenListIndex++;
				nbReturnedElements++;
				return value;
			}
			currenListIndex = 0;
			currentValue = null;
		}
		return super.next();
	}

	public Object getValueAt(INode node, int currentIndex) {
		if (currentValue == null) {
			currentValue = (List) node.getValueAsObjectAt(currentIndex);
		}
		int listSize = currentValue.size();
		if (listSize > currenListIndex) {
			Object value = currentValue.get(currenListIndex);
			currenListIndex++;
			return value;
		}
		currenListIndex = 0;
		currentValue = null;
		return null;
	}

	@Override
	public List<INode> retrieveByBreadth(List<INode> allChindNodes) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<INode> retrieveByDepth(INode binNode) {
		// TODO Auto-generated method stub
		return null;
	}
}
