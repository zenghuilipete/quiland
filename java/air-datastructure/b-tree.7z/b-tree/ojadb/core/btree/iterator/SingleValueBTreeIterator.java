/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.iterator;

import java.util.ArrayList;
import java.util.List;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.INode;
import ojadb.core.btree.ISingleValueNode;
import ojadb.core.btree.parameter.OrderByType;

public class SingleValueBTreeIterator extends BTreeIterator{
	public SingleValueBTreeIterator(IBTree tree, OrderByType orderByType) {
		super(tree, orderByType);
	}

	public Object getValueAt(INode node, int currentIndex) {
		ISingleValueNode n = (ISingleValueNode) node;
		return n.getValueAt(currentIndex);
	}

	/**
	 * 深度优先遍历显示树
	 */
	public List<INode> retrieveByDepth(INode baseNodes) {
		return retrieveByDepth(baseNodes, 0);
	}

	public List<INode> retrieveByDepth(INode baseNode, int height) {
		List<INode> resultList = new ArrayList<INode>();
		if (baseNode.isRoot()) {
			baseNode.setHeight(height++);
			resultList.add(baseNode);
		}
		List<INode> childNodes = baseNode.getChildrenNodes();
		if (childNodes != null && childNodes.size() != 0) {
			for (INode node : childNodes) {
				node.setHeight(height);
				resultList.add(node);
				List nodeList = retrieveByDepth(node, ++height);
				height--;
				resultList.addAll(nodeList);
			}
		}
		return resultList;
	}

	/**
	 * 广度优先遍历显示树
	 */
	public List<INode> retrieveByBreadth(List<INode> allChindNodes) {
		return retrieveByBreadth(allChindNodes, 0);
	}

	public List<INode> retrieveByBreadth(List<INode> allChindNodes, int height) {
		List<INode> resultList = new ArrayList<INode>();
		List<INode> allChindNodesCache = new ArrayList<INode>();
		if (allChindNodes != null && allChindNodes.size() != 0) {
			for (INode node : allChindNodes) {
				node.setHeight(height);
				resultList.add(node);
				List<INode> childrenNodes = node.getChildrenNodes();
				if (childrenNodes != null && childrenNodes.size() > 0)
					allChindNodesCache.addAll(node.getChildrenNodes());
			}
		}
		if (allChindNodesCache.size() != 0) {
			List<INode> nodeList = retrieveByBreadth(allChindNodesCache, ++height);
			resultList.addAll(nodeList);
		}
		return resultList;
	}
}
