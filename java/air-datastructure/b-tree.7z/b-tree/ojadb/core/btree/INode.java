/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree;

import java.io.Serializable;
import java.util.List;

public interface INode extends Serializable {
	/**
	 * 结点标识
	 * 
	 * @return
	 */
	Long getId();

	void setId(Long id);

	/**
	 * 结点是否已满
	 * 
	 * @return
	 */
	boolean isFull();

	/**
	 * 结点是否为叶子结点
	 * 
	 * @return
	 */
	boolean isLeaf();

	/**
	 * 结点是否为根结点
	 * 
	 * @return
	 */
	boolean isRoot();

	/**
	 * 结点的父结点
	 * 
	 * @param node
	 */
	void setParent(INode node);

	INode getParent();

	/**
	 * 结点是否有父结点
	 * 
	 * @return
	 */
	boolean hasParent();

	/**
	 * 获取父结点标识
	 * 
	 * @return
	 */
	Long getParentId();

	/**
	 * 结点所在树的层次
	 * 
	 * @param height
	 */
	void setHeight(int height);

	int getHeight();

	/**
	 * 结点所在树的阶
	 * 
	 * @return
	 */
	int getDegree();

	/**
	 * 获取结点所在树
	 * 
	 * @return
	 */
	IBTree getBTree();

	void setBTree(IBTree btree);

	/**
	 * 结点中关键字的数量
	 * 
	 * @return
	 */
	int getKeysCount();

	void setKeysCount(int keysCount);

	void incrementKeysCount();

	/**
	 * 结点的子结点数量
	 * 
	 * @return
	 */
	int getChildrenCount();

	void setChildrenCount(int childrenCount);

	void incrementChildrenCount();

	/**
	 * 结点最多拥有孩子的数量
	 * 
	 * @return
	 */
	int getMaxChildren();

	/**
	 * 获取结点的所有结点
	 * 
	 * @return
	 */
	List<INode> getChildrenNodes();

	/**
	 * 清空结点
	 */
	void clear();

	/**
	 * 获取结点中的中间位置的键值对
	 * 
	 * @return
	 */
	IKeyAndValue getMedian();

	/**
	 * 获取键值对
	 * 
	 * @param index
	 * @return
	 */
	IKeyAndValue getKeyAndValueAt(int index);

	/**
	 * 获取结点中最后一个键值对
	 * 
	 * @return
	 */
	public IKeyAndValue getLastKeyAndValue();

	/**
	 * 获取键
	 * 
	 * @param index
	 * @return
	 */
	public Comparable getKeyAt(int index);

	/**
	 * 获取值
	 * 
	 * @param index
	 * @return
	 */
	public Object getValueAsObjectAt(int index);

	/**
	 * 获取键所在结点中的位置
	 * 
	 * @param key
	 * @return
	 */

	int getPositionOfKey(Comparable key);

	/**
	 * 在index位置获取孩子结点
	 * 
	 * @param index
	 * @param throwExceptionIfNotExist
	 * @return
	 */
	INode getChildAt(int index, boolean throwExceptionIfNotExist);

	Object getChildIdAt(int childIndex, boolean throwExceptionIfDoesNotExist);

	void setChildAt(INode child, int index);

	void setChildAt(INode node, int childIndex, int indexDestination, boolean throwExceptionIfDoesNotExist);

	void deleteChildAt(int index);

	public void setNullChildAt(int childIndex);

	/**
	 * 在index位置放入键值对
	 * 
	 * @param key
	 * @param value
	 * @param index
	 */
	void setKeyAndValueAt(Comparable key, Object value, int index);

	void setKeyAndValueAt(Comparable key, Object value, int index, boolean shiftIfAlreadyExist, boolean incrementNbKeys);

	void setKeyAndValueAt(IKeyAndValue keyAndValue, int index);

	void setKeyAndValueAt(IKeyAndValue keyAndValue, int index, boolean shiftIfAlreadyExist, boolean incrementNbKeys);

	/**
	 * 获取结点信息
	 * 
	 * @return
	 */
	String getInfo();

	/**
	 * 插入键值对
	 * 
	 * @param key
	 * @param value
	 */
	void insertKeyAndValue(Comparable key, Object value);

	/**
	 * 删除键值对
	 * 
	 * @param index
	 */
	void removeKeyAndValueAt(int index);

	Object deleteKeyAndValueAt(int index, boolean shiftChildren);

	/**
	 * 从子结点删除键值对
	 * 
	 * @param keyAndValue
	 * @return
	 */
	Object deleteKeyForLeafNode(IKeyAndValue keyAndValue);

	/**
	 * 与另外一个结点合并
	 * 
	 * @param node
	 */
	void mergeWith(INode node);

	/**
	 * 移动子结点
	 * @param sourceIndex
	 * @param destinationIndex
	 * @param throwExceptionIfDoesNotExist
	 */
	void moveChildFromTo(int sourceIndex, int destinationIndex, boolean throwExceptionIfDoesNotExist);

	/**
	 * 获取分解结点时右半部结点(自己是左半部)
	 * 
	 * @return
	 */
	INode extractRightPart();

	/**
	 * 获取结点最后的一个子结点
	 * 
	 * @return
	 */
	INode getLastChild();

	/**
	 * 获取序号为子结点最大数量的子结点
	 * 
	 * @return
	 */
	INode getLastPositionChild();
}
