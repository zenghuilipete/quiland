/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree;

import java.io.Serializable;
import java.util.List;
import ojadb.core.btree.iterator.BTreeIterator;
import ojadb.core.btree.parameter.OrderByType;

public interface IBTree<E> extends Serializable {
	/**
	 * 构建结点
	 * 
	 * @return
	 */
	INode buildNode();

	/**
	 * 设置树标识
	 * 
	 * @param id
	 */
	void setId(Long id);

	/**
	 * 获取树标识
	 * 
	 * @return
	 */
	Long getId();

	/**
	 * 分解树结点
	 * 
	 * @param parent
	 * @param node2Split
	 * @param childIndex
	 */
	void split(INode parent, INode node2Split, int childIndex);

	/**
	 * 树阶
	 * 
	 * @return
	 */
	int getDegree();

	/**
	 * 树高
	 * 
	 * @return
	 */
	int getHeight();

	/**
	 * 清空树
	 */
	void clear();

	/**
	 * 根结点
	 * 
	 * @return
	 */
	INode getRoot();

	/**
	 * 树的结点数
	 * 
	 * @return
	 */
	int getSize();

	/**
	 * 关键字最小值
	 * 
	 * @param node
	 * @param delete
	 * @return
	 */
	IKeyAndValue getSmallest(INode node, boolean delete);

	/**
	 * 关键字最大值
	 * 
	 * @param node
	 * @param delete
	 * @return
	 */
	IKeyAndValue getBiggest(INode node, boolean delete);

	/**
	 * 插入关键字
	 * 
	 * @param key
	 * @param value
	 */
	void insert(Comparable<E> key, Object value);

	/**
	 * 删除关键字
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	Object delete(Comparable<E> key, Object value);

	/**
	 * 查找关键字
	 * 
	 * @param key
	 * @return
	 */
	List search(Comparable key);

	/**
	 * 迭代器
	 * 
	 * @return
	 */
	BTreeIterator iterator();

	/**
	 * 迭代器
	 * 
	 * @param orderBy
	 * @return
	 */
	BTreeIterator iterator(OrderByType orderBy);

}
