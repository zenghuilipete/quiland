/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.tool;

import ojadb.core.btree.INode;
import ojadb.core.btree.ISingleValueNode;
import ojadb.core.btree.IKeyAndValue;
import ojadb.core.btree.parameter.BTreeNodeValidationException;

public class BTreeValidator {
	private static boolean on = false;

	public static boolean isOn() {
		return BTreeValidator.on;
	}

	public static void setOn(boolean on) {
		BTreeValidator.on = on;
	}

	public static void checkDuplicateChildren(INode node1, INode node2) {
		if (!on) {
			return;
		}
		for (int i = 0; i < node1.getChildrenCount(); i++) {
			INode child1 = node1.getChildAt(i, true);
			for (int j = 0; j < node2.getChildrenCount(); j++) {
				if (child1 == node2.getChildAt(j, true)) {
					throw new BTreeNodeValidationException("结点重复 : " + child1);
				}
			}
		}
	}

	public static void validateNode(INode node, boolean isRoot) {
		if (!on) {
			return;
		}
		validateNode(node);
		if (isRoot && node.hasParent()) {
			throw new BTreeNodeValidationException("根结点含有父结点: " + node.toString());
		}
		if (!isRoot && !node.hasParent()) {
			throw new BTreeNodeValidationException("内部结点没有父结点: " + node.toString());
		}
	}

	public static void validateNode(INode node) {
		if (!on) {
			return;
		}
		int nbKeys = node.getKeysCount();
		if (node.hasParent() && nbKeys < node.getDegree() - 1) {
			throw new BTreeNodeValidationException("结点少于 " + (node.getDegree() - 1) + " 个keys");
		}
		int maxNbKeys = node.getDegree() * 2 - 1;
		int nbChildren = node.getChildrenCount();
		int maxNbChildren = node.getDegree() * 2;
		if (nbChildren != 0 && nbKeys == 0) {
			throw new BTreeNodeValidationException("结点没有key 但是含有子结点 : " + node);
		}
		for (int i = 0; i < nbKeys; i++) {
			if (node.getKeyAndValueAt(i) == null) {
				throw new BTreeNodeValidationException("第" + i + "结点" + node.toString() + " key为空");
			}
			checkValuesOfChild(node.getKeyAndValueAt(i), node.getChildAt(i, false));
		}
		for (int i = nbKeys; i < maxNbKeys; i++) {
			if (node.getKeyAndValueAt(i) != null) {
				throw new BTreeNodeValidationException("第" + i + "结点" + node.toString() + " key为空");
			}
		}
		INode previousNode = null;
		for (int i = 0; i < nbChildren; i++) {
			if (node.getChildAt(i, false) == null) {
				throw new BTreeNodeValidationException("第" + i + "结点" + node.toString() + " 子结点为空");
			}
			if (previousNode != null && previousNode == node.getChildAt(i, false)) {
				throw new BTreeNodeValidationException("第" + i + " : " + previousNode.toString() + "有两个相同的子结点");
			}
			previousNode = node.getChildAt(i, false);
		}
		for (int i = nbChildren; i < maxNbChildren; i++) {
			if (node.getChildAt(i, false) != null) {
				throw new BTreeNodeValidationException("第" + i + "结点" + node.toString() + " 子结点非空");
			}
		}
	}

	private static void checkValuesOfChild(IKeyAndValue key, INode node) {
		if (!on) {
			return;
		}
		if (node == null) {
			return;
		}
		for (int i = 0; i < node.getKeysCount(); i++) {
			if (node.getKeyAndValueAt(i).getKey().compareTo(key.getKey()) >= 0) {
				throw new BTreeNodeValidationException("左子结点的值大于 pivot " + key + " : " + node.toString());
			}
		}
	}

	public static boolean searchKey(Comparable key, ISingleValueNode node) {
		if (!on) {
			return false;
		}
		for (int i = 0; i < node.getKeysCount(); i++) {
			if (node.getKeyAndValueAt(i).getKey().compareTo(key) == 0) {
				return true;
			}
		}
		return false;
	}
}
