/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl.singlevalue;

import ojadb.core.btree.IBTree;
import ojadb.core.btree.ISingleValueNode;
import ojadb.core.btree.impl.AbstractNode;
import ojadb.core.btree.parameter.DuplicatedKeyException;

public abstract class SingleValueNode extends AbstractNode implements ISingleValueNode {
	private static final long serialVersionUID = -4169158123974262823L;

	public SingleValueNode() {
		super();
	}

	public SingleValueNode(IBTree btree) {
		super(btree);
	}

	public Object getValueAt(int index) {
		return values[index];
	}

	public void insertKeyAndValue(Comparable key, Object value) {
		int position = getPositionOfKey(key);
		int realPosition = 0;
		if (position >= 0) {
			throw new DuplicatedKeyException(String.valueOf(key));
		}
		realPosition = -position - 1;
		if (realPosition < currentKeyCount) {
			rightShiftFrom(realPosition, true);
		}
		keys[realPosition] = key;
		values[realPosition] = value;
		currentKeyCount++;
	}

	public Object search(Comparable key) {
		int position = getPositionOfKey(key);
		boolean keyIsHere = position > 0;
		int realPosition = -1;
		if (keyIsHere) {
			realPosition = position - 1;
			Object value = getValueAt(realPosition);
			return value;
		} else if (isLeaf()) {
			return null;
		}
		realPosition = -position - 1;
		ISingleValueNode node = (ISingleValueNode) getChildAt(realPosition, true);
		return node.search(key);
	}
}
