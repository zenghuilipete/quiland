/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl.singlevalue;

import java.util.ArrayList;
import java.util.List;
import ojadb.core.btree.ISingleValueBTree;
import ojadb.core.btree.ISingleValueNode;
import ojadb.core.btree.impl.AbstractBTree;
import ojadb.core.btree.iterator.BTreeIterator;
import ojadb.core.btree.iterator.SingleValueBTreeIterator;
import ojadb.core.btree.parameter.OrderByType;

public abstract class SingleValueBTree extends AbstractBTree implements ISingleValueBTree{
	private static final long serialVersionUID = 3056665327883405493L;

	public SingleValueBTree() {}

	public SingleValueBTree(String name, int degree) {
		super(name, degree);
	}

	public List search(Comparable key) {
		ISingleValueNode theRoot = (ISingleValueNode) getRoot();
		List list = new ArrayList();
		list.add(theRoot.search(key));
		return list;
	}

	public BTreeIterator iterator(OrderByType orderBy) {
		return new SingleValueBTreeIterator(this, orderBy);
	}

	public BTreeIterator iterator() {
		return new SingleValueBTreeIterator(this, OrderByType.ORDER_BY_ASC);
	}
}