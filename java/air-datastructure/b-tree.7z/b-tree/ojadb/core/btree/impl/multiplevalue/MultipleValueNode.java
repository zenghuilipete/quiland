/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl.multiplevalue;

import java.util.ArrayList;
import java.util.List;
import ojadb.core.btree.IBTree;
import ojadb.core.btree.IMultipleValueNode;
import ojadb.core.btree.IKeyAndValue;
import ojadb.core.btree.impl.AbstractNode;
import ojadb.core.btree.parameter.BTreeException;
import ojadb.core.btree.tool.BTreeValidator;

public abstract class MultipleValueNode extends AbstractNode implements IMultipleValueNode {
	private static final long serialVersionUID = -1855731276408442831L;

	public MultipleValueNode() {
		super();
	}

	public MultipleValueNode(IBTree btree) {
		super(btree);
	}

	public List getValueAt(int index) {
		return (List) values[index];
	}

	public void insertKeyAndValue(Comparable key, Object value) {
		//
		int position = getPositionOfKey(key);
		boolean addToExistingCollection = false;
		
		int realPosition = 0;
		if (position >= 0) {
			//加入已有的数组
			addToExistingCollection = true;
			realPosition = position - 1;
		} else {
			realPosition = -position - 1;
		}
		
		
		Comparable realKey=keys[realPosition];
		if (realPosition < currentKeyCount && key.compareTo(realKey) != 0) {
			//向右移动数组内关键字值
			rightShiftFrom(realPosition, true);
		}
		
		keys[realPosition] = key;
		manageCollectionValue(realPosition, value);
		if (!addToExistingCollection) {
			currentKeyCount++;
		}
	}

	private void manageCollectionValue(int realPosition, Object value) {
		Object o = values[realPosition];
		if (o == null) {
			o = new ArrayList();
			values[realPosition] = o;
		} else {
			if (!(o instanceof List)) {
				throw new BTreeException("关键字值不唯一的BTree 对象值要保存在collection中，而不是" + o.getClass().getName()+" 中");
			}
		}
		List l = (List) o;
		l.add(value);
	}

	public List search(Comparable key) {
		int position = getPositionOfKey(key);
		boolean keyIsHere = position > 0;
		int realPosition = -1;
		if (keyIsHere) {
			realPosition = position - 1;
			List value = getValueAt(realPosition);
			return value;
		} else if (isLeaf()) {
			return null;
		}
		realPosition = -position - 1;
		IMultipleValueNode node = (IMultipleValueNode) getChildAt(realPosition, true);
		return node.search(key);
	}

	public Object deleteKeyForLeafNode(IKeyAndValue keyAndValue) {
		boolean objectHasBeenFound = false;
		int position = getPositionOfKey(keyAndValue.getKey());
		if (position < 0) {
			return null;
		}
		int realPosition = position - 1;
		List value = (List) values[realPosition];
		// Here we must search for the right object. The list can contains more than 1 object
		int size = value.size();
		for (int i = 0; i < size && !objectHasBeenFound; i++) {
			if (value.get(i).equals(keyAndValue.getValue())) {
				value.remove(i);
				objectHasBeenFound = true;
			}
		}
		if (!objectHasBeenFound) {
			return null;
		}
		if (value.size() == 0) {
			leftShiftFrom(realPosition, false);
			currentKeyCount--;
		}
		BTreeValidator.validateNode(this);
		return keyAndValue.getValue();
	}
}
