/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import ojadb.core.btree.IBTree;
import ojadb.core.btree.IKeyAndValue;
import ojadb.core.btree.INode;
import ojadb.core.btree.parameter.BTreeException;
import ojadb.core.btree.parameter.BTreeNodeValidationException;
import ojadb.core.btree.tool.BTreeValidator;

public abstract class AbstractNode implements INode {
	private static final long serialVersionUID = -4823803377974485507L;
	protected static AtomicLong nextId = new AtomicLong(1);
	// 结点标识
	protected Long nodeId;
	// 树的深度
	protected int degree;
	// 结点上的关键字数组
	protected Comparable[] keys;
	// 结点上的对象数组
	protected Object[] values;
	// 结点上当前关键字数量
	protected int currentKeyCount;
	// 结点上当前孩子结点数量
	protected int currentChildrenCount;
	// 结点上的关键字最大数量
	protected int maxKeyCount;
	// 结点最多拥有的孩子结点数量
	protected int maxChildrenCount;
	// 结点所在的树
	transient protected IBTree btree;
	// 结点的子结点
	protected INode[] childrenNodes;
	// 结点的父结点
	protected INode parentNode;
	protected transient INode parent;

	// 结点是所在的树的第几层结点
	protected int height = -1;

	public AbstractNode() {
		this.btree = null;
		this.degree = -1;
		this.maxKeyCount = -1;
		this.maxChildrenCount = -1;
		keys = null;
		values = null;
		currentKeyCount = 0;
		currentChildrenCount = 0;
	}

	public AbstractNode(IBTree btree) {
		basicInit(btree);
	}

	private void basicInit(IBTree btree) {
		this.btree = btree;
		this.degree = btree.getDegree();
		this.maxKeyCount = 2 * degree - 1;
		this.maxChildrenCount = 2 * degree;
		keys = new Comparable[maxKeyCount];
		values = new Object[maxKeyCount];
		currentKeyCount = 0;
		currentChildrenCount = 0;
		init();
	}

	public IBTree getBTree() {
		return btree;
	}

	public int getDegree() {
		return degree;
	}

	public int getHeight() {
		return height;
	}

	public void setChildrenCount(int nbChildren) {
		this.currentChildrenCount = nbChildren;
	}

	public void setKeysCount(int nbKeys) {
		this.currentKeyCount = nbKeys;
	}

	public void setParent(INode node) {
		parent = node;
		if (parent != null) {
			parentNode = parent;
		} else {
			parentNode = null;
		}
	}

	public void clear() {
		basicInit(btree);
	}

	public Comparable getKeyAt(int index) {
		return keys[index];
	}

	public INode getLastChild() {
		return getChildAt(currentChildrenCount - 1, true);
	}

	public IKeyAndValue getLastKeyAndValue() {
		return getKeyAndValueAt(currentKeyCount - 1);
	}

	public INode getLastPositionChild() {
		return getChildAt(maxChildrenCount - 1, false);
	}

	public int getMaxChildren() {
		return maxChildrenCount;
	}

	public IKeyAndValue getMedian() {
		int medianPosition = degree - 1;
		return getKeyAndValueAt(medianPosition);
	}

	public int getChildrenCount() {
		return currentChildrenCount;
	}

	public int getKeysCount() {
		return currentKeyCount;
	}

	public INode getParent() {
		if (parent != null) {
			return parent;
		}
		return null;
	}

	public abstract Long getParentId();

	public boolean hasParent() {
		return parentNode != null;
	}

	public void incrementChildrenCount() {
		currentChildrenCount++;
	}

	public void incrementKeysCount() {
		currentKeyCount++;
	}

	protected abstract void init();

	public abstract void insertKeyAndValue(Comparable key, Object value);

	public boolean isFull() {
		return currentKeyCount == maxKeyCount;
	}

	public boolean isLeaf() {
		return currentChildrenCount == 0;
	}

	@Override
	public boolean isRoot() {
		return parent == null;
	}

	public void setBTree(IBTree btree) {
		this.btree = btree;
	}

	/**
	 * @param height
	 *            the height to set
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	private void checkIfCanMergeWith(INode node) {
		if (currentKeyCount + node.getKeysCount() > maxKeyCount) {
			throw new BTreeException("Trying to merge two nodes with too many keys " + currentKeyCount + " + " + node.getKeysCount() + " > " + maxKeyCount);
		}
		if (currentKeyCount > 0) {
			Comparable greatestOfThis = keys[currentKeyCount - 1];
			Comparable smallestOfOther = node.getKeyAt(0);
			if (greatestOfThis.compareTo(smallestOfOther) >= 0) {
				throw new BTreeNodeValidationException("Trying to merge two nodes that have intersections :  " + toString() + " / " + node);
			}
		}
		if (currentKeyCount < currentChildrenCount) {
			throw new BTreeNodeValidationException("Trying to merge two nodes where the first one has more children than keys");
		}
	}

	public Object deleteKeyAndValueAt(int keyIndex, boolean shiftChildren) {
		Object currentValue = values[keyIndex];
		leftShiftFrom(keyIndex, shiftChildren);
		currentKeyCount--;
		if (shiftChildren && currentChildrenCount > keyIndex) {
			currentChildrenCount--;
		}
		return currentValue;
	}

	/**
	 * 删除结点上的键值对
	 */
	public Object deleteKeyForLeafNode(IKeyAndValue keyAndValue) {
		int position = getPositionOfKey(keyAndValue.getKey());
		if (position < 0) {
			return null;
		}
		int realPosition = position - 1;
		Object value = values[realPosition];
		leftShiftFrom(realPosition, false);
		currentKeyCount--;
		BTreeValidator.validateNode(this);
		return value;
	}

	/**
	 * 从position向左移动键值对
	 * 
	 * @param position
	 * @param shiftChildren
	 */
	protected void leftShiftFrom(int position, boolean shiftChildren) {
		for (int i = position; i < currentKeyCount - 1; i++) {
			keys[i] = keys[i + 1];
			values[i] = values[i + 1];
			if (shiftChildren) {
				moveChildFromTo(i + 1, i, false);
			}
		}
		keys[currentKeyCount - 1] = null;
		values[currentKeyCount - 1] = null;
		if (shiftChildren) {
			moveChildFromTo(currentKeyCount, currentKeyCount - 1, false);
			setNullChildAt(currentKeyCount);
		}
	}

	/**
	 * 从position向右移动键值对
	 * 
	 * @param position
	 * @param shiftChildren
	 */
	protected void rightShiftFrom(int position, boolean shiftChildren) {
		if (isFull()) {
			throw new BTreeException("结点关键字值已满，无法向右移动");
		}
		for (int i = currentKeyCount; i > position; i--) {
			keys[i] = keys[i - 1];
			values[i] = values[i - 1];
		}
		keys[position] = null;
		values[position] = null;
		if (shiftChildren) {
			for (int i = currentChildrenCount; i > position; i--) {
				moveChildFromTo(i - 1, i, true);
			}
			setNullChildAt(position);
		}
	}

	public abstract void moveChildFromTo(int sourceIndex, int destinationIndex, boolean throwExceptionIfDoesNotExist);

	/**
	 * 右半
	 * 
	 * @see INode
	 */
	public INode extractRightPart() {
		if (!isFull()) {
			throw new BTreeException("extract right part called on non full node");
		}
		INode rightPart = btree.buildNode();
		int j = 0;
		for (int i = degree; i < maxKeyCount; i++) {
			rightPart.setKeyAndValueAt(keys[i], values[i], j, false, false);
			keys[i] = null;
			values[i] = null;
			rightPart.setChildAt(this, i, j, false);
			INode c = rightPart.getChildAt(j, false);
			if (c != null) {
				c.setParent(rightPart);
			}
			setNullChildAt(i);
			j++;
		}
		rightPart.setChildAt(this, getMaxChildren() - 1, j, false);
		INode c1 = rightPart.getChildAt(j, false);
		if (c1 != null) {
			c1.setParent(rightPart);
		}
		setNullChildAt(maxChildrenCount - 1);
		keys[degree - 1] = null;
		values[degree - 1] = null;
		currentKeyCount = degree - 1;
		int originalNbChildren = currentChildrenCount;
		currentChildrenCount = Math.min(currentChildrenCount, degree);
		rightPart.setKeysCount(degree - 1);
		rightPart.setChildrenCount(originalNbChildren - currentChildrenCount);
		BTreeValidator.validateNode(this);
		BTreeValidator.validateNode(rightPart);
		BTreeValidator.checkDuplicateChildren(this, rightPart);
		return rightPart;
	}

	public abstract INode getChildAt(int index, boolean throwExceptionIfNotExist);

	/**
	 * 获取结点的所有子结点
	 */
	public List<INode> getChildrenNodes() {
		if (childrenNodes.length == 0)
			return null;
		List<INode> list = new ArrayList<INode>();
		for (INode iNode : childrenNodes) {
			if (iNode == null) {
				return list;
			}
			list.add(iNode);
		}
		return list;
	}

	public IKeyAndValue getKeyAndValueAt(int index) {
		if (keys[index] == null && values[index] == null) {
			return null;
		}
		return new KeyAndValue(keys[index], values[index]);
	}

	/**
	 * 确定key在当前key数组位置 向左多少个位置，或者向右多少个位置
	 */
	public int getPositionOfKey(Comparable key) {
		int i = 0;
		while (i < currentKeyCount) {
			Comparable currentKey = keys[i];
			int result = currentKey.compareTo(key);
			// 关键字值相等，指针向右+1
			if (result == 0) {
				return i + 1;
			}
			// 数组中当前关键字值大于新关键字值
			if (result > 0) {
				return -(i + 1);
			}
			i++;
		}
		return -(i + 1);
	}

	public void mergeWith(INode node) {
		BTreeValidator.validateNode(this);
		BTreeValidator.validateNode(node);
		checkIfCanMergeWith(node);
		int j = currentKeyCount;
		for (int i = 0; i < node.getKeysCount(); i++) {
			setKeyAndValueAt(node.getKeyAt(i), node.getValueAsObjectAt(i), j, false, false);
			setChildAt(node, i, j, false);
			j++;
		}
		// in this, we have to take the last child
		if (node.getChildrenCount() > node.getKeysCount()) {
			setChildAt(node, node.getChildrenCount() - 1, j, true);
		}
		currentKeyCount += node.getKeysCount();
		currentChildrenCount += node.getChildrenCount();
		BTreeValidator.validateNode(this);
	}

	public void removeKeyAndValueAt(int index) {
		throw new BTreeException("Not implemented");
	}

	public void setKeyAndValueAt(Comparable key, Object value, int index) {
		keys[index] = key;
		values[index] = value;
	}

	public void setKeyAndValueAt(Comparable key, Object value, int index, boolean shiftIfAlreadyExist, boolean incrementNbKeys) {
		if (shiftIfAlreadyExist && index < currentKeyCount) {
			rightShiftFrom(index, true);
		}
		keys[index] = key;
		values[index] = value;
		if (incrementNbKeys) {
			currentKeyCount++;
		}
	}

	public void setKeyAndValueAt(IKeyAndValue keyAndValue, int index) {
		setKeyAndValueAt(keyAndValue.getKey(), keyAndValue.getValue(), index);
	}

	public void setKeyAndValueAt(IKeyAndValue keyAndValue, int index, boolean shiftIfAlreadyExist, boolean incrementNbKeys) {
		setKeyAndValueAt(keyAndValue.getKey(), keyAndValue.getValue(), index, shiftIfAlreadyExist, incrementNbKeys);
	}

	// id=270 {keys(1)=(13), child(2)}
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("id=").append(getId()).append(" {keys(").append(currentKeyCount).append(")=(");
		for (int i = 0; i < currentKeyCount; i++) {
			if (i > 0) {
				buffer.append(",");
			}
			buffer.append(keys[i]);
		}
		buffer.append("), child(").append(currentChildrenCount).append(")}");
		return buffer.toString();
	}
}
