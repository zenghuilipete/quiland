/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl;

import ojadb.core.btree.IBTree;
import ojadb.core.btree.IKeyAndValue;
import ojadb.core.btree.INode;
import ojadb.core.btree.parameter.BTreeNodeValidationException;
import ojadb.core.btree.tool.BTreeValidator;

public abstract class AbstractBTree implements IBTree {
	private static final long serialVersionUID = 3378532402212897753L;
	private String name;
	private int degree;
	private int size;
	private int height;
	private INode root;
	protected int controlNumber;

	public abstract INode buildNode();

	public AbstractBTree() {
		this.degree = 0;
		this.size = 0;
		this.height = 1;
		root = null;
	}

	public AbstractBTree(String name, int degree) {
		this.name = name;
		this.degree = degree;
		this.size = 0;
		this.height = 1;
		root = buildNode();
	}

	public Object delete(Comparable key, Object value) {
		Object o = null;
		try {
			o = internalDelete(root, new KeyAndValue(key, value));
		} catch (Exception e) {
			throw new BTreeNodeValidationException("删除数据出错： key='" + key + "' value='" + value + "'", e);
		}
		if (o != null) {
			size--;
		}
		return o;
	}

	/**
	 * 删除键值对 删除数据按至上而下查找合适的结点，删除时判断结点关键字数量不能少于树的阶
	 * 
	 * @param node
	 * @param keyAndValue
	 * @return
	 * @throws Exception
	 */
	protected Object internalDelete(INode node, IKeyAndValue keyAndValue) throws Exception {
		int position = node.getPositionOfKey(keyAndValue.getKey());
		boolean isHere = position > 0;
		int realPosition = -1;
		INode leftNode = null;
		INode rightNode = null;
		try {
			// 至上而下，如果是叶子结点，有则删除，没有返回为空
			if (node.isLeaf()) {
				if (isHere) {
					Object deletedValue = node.deleteKeyForLeafNode(keyAndValue);
					return deletedValue;
				}
				return null;
			}

			// 递归获取合适的删除结点
			if (!isHere) {
				realPosition = -position - 1;
				INode child = node.getChildAt(realPosition, true);
				// 如果该结点关键字数量少于树的阶
				if (child.getKeysCount() == degree - 1) {
					node = prepareForDelete(node, child, realPosition);
					return internalDelete(node, keyAndValue);
				}
				return internalDelete(child, keyAndValue);
			}

			//
			realPosition = position - 1;
			Comparable currentKey = node.getKeyAt(realPosition);
			Object currentValue = node.getValueAsObjectAt(realPosition);

			// 如果该结点关键字数量多于树的阶 直接删除
			// case 2a
			leftNode = node.getChildAt(realPosition, true);
			if (leftNode.getKeysCount() >= degree) {
				IKeyAndValue prev = getBiggest(leftNode, true);
				node.setKeyAndValueAt(prev, realPosition);
				BTreeValidator.validateNode(node, node == root);
				return currentValue;
			}
			// case 2b
			rightNode = node.getChildAt(realPosition + 1, true);
			if (rightNode.getKeysCount() >= degree) {
				IKeyAndValue next = getSmallest(rightNode, true);
				node.setKeyAndValueAt(next, realPosition);
				BTreeValidator.validateNode(node, node == root);
				return currentValue;
			}
			// case 2c
			node.deleteKeyAndValueAt(realPosition, true);
			leftNode.insertKeyAndValue(currentKey, currentValue);
			leftNode.mergeWith(rightNode);

			// 如果该结点为根结点或者为空
			if (!node.hasParent() && node.getKeysCount() == 0) {
				root = leftNode;
				leftNode.setParent(null);
				height--;
			} else {
				node.setChildAt(leftNode, realPosition);
				BTreeValidator.validateNode(node, node == root);
			}
			BTreeValidator.validateNode(leftNode, leftNode == root);
			// 递归删除
			return internalDelete(leftNode, keyAndValue);
		} finally {
		}
	}

	private INode prepareForDelete(INode parent, INode child, int childIndex) {
		BTreeValidator.validateNode(parent);
		BTreeValidator.validateNode(child);
		
		//键值对在数组中的位置n和孩子结点的位置的关系是：KV{child[n-1]}<KV[n-1]<KV{child[n]}
		// case 3a
		INode leftSibling = null;
		INode rightSibling = null;
		try {
			if (childIndex > 0 && parent.getChildrenCount() > 0) {
				//child的左兄弟结点
				leftSibling = parent.getChildAt(childIndex - 1, false);
			}
			if (childIndex < parent.getChildrenCount() - 1) {
				//child的右兄弟结点
				rightSibling = parent.getChildAt(childIndex + 1, false);
			}
			// case 3a left
			if (leftSibling != null && leftSibling.getKeysCount() >= degree) {
				IKeyAndValue elementToMoveDown = parent.getKeyAndValueAt(childIndex - 1);
				IKeyAndValue elementToMoveUp = leftSibling.getLastKeyAndValue();
				parent.setKeyAndValueAt(elementToMoveUp, childIndex - 1);
				child.insertKeyAndValue(elementToMoveDown.getKey(), elementToMoveDown.getValue());
				
				if (leftSibling.getChildrenCount() > leftSibling.getKeysCount()) {
					child.setChildAt(leftSibling, leftSibling.getChildrenCount() - 1, 0, true);
					child.incrementChildrenCount();
				}
				leftSibling.deleteKeyAndValueAt(leftSibling.getKeysCount() - 1, false);
				if (!leftSibling.isLeaf()) {
					leftSibling.deleteChildAt(leftSibling.getChildrenCount() - 1);
				}
				if (BTreeValidator.isOn()) {
					BTreeValidator.validateNode(parent, parent == root);
					BTreeValidator.validateNode(child, false);
					BTreeValidator.validateNode(leftSibling, false);
					BTreeValidator.checkDuplicateChildren(leftSibling, child);
				}
				return parent;
			}
			// case 3a right
			if (rightSibling != null && rightSibling.getKeysCount() >= degree) {
				IKeyAndValue elementToMoveDown = parent.getKeyAndValueAt(childIndex);
				IKeyAndValue elementToMoveUp = rightSibling.getKeyAndValueAt(0);
				parent.setKeyAndValueAt(elementToMoveUp, childIndex);
				child.insertKeyAndValue(elementToMoveDown.getKey(), elementToMoveDown.getValue());
				if (rightSibling.getChildrenCount() > 0) {
					child.setChildAt(rightSibling, 0, child.getChildrenCount(), true);
					child.incrementChildrenCount();
				}
				rightSibling.deleteKeyAndValueAt(0, true);
				if (BTreeValidator.isOn()) {
					BTreeValidator.validateNode(parent, parent == root);
					BTreeValidator.validateNode(child, false);
					BTreeValidator.validateNode(rightSibling, false);
					BTreeValidator.checkDuplicateChildren(rightSibling, child);
				}
				return parent;
			}
			
			// case 3b
			boolean l = leftSibling != null && leftSibling.getKeysCount() == degree - 1;
			boolean r = rightSibling != null && rightSibling.getKeysCount() >= degree - 1;
			boolean isCase3b = l || r;
			boolean parentWasSetToNull = false;
			if (isCase3b) {
				// choose left sibling to execute merge
				if (leftSibling != null) {
					IKeyAndValue elementToMoveDown = parent.getKeyAndValueAt(childIndex - 1);
					leftSibling.insertKeyAndValue(elementToMoveDown.getKey(), elementToMoveDown.getValue());
					leftSibling.mergeWith(child);
					parent.deleteKeyAndValueAt(childIndex - 1, true);
					if (parent.getKeysCount() == 0) {
						// 根结点条件
						if (!parent.hasParent()) {
							root = leftSibling;
							root.setParent(null);
							height--;
							parentWasSetToNull = true;
						} else {
							throw new BTreeNodeValidationException("非根结点没有父结点!");
						}
					} else {
						parent.setChildAt(leftSibling, childIndex - 1);
					}
					if (parentWasSetToNull) {
					} else {
						BTreeValidator.validateNode(parent, parent == root);
					}
					BTreeValidator.validateNode(leftSibling, leftSibling == root);
					if (parentWasSetToNull) {
						return root;
					}
					return parent;
				}
				// choose right sibling to execute merge
				if (rightSibling != null) {
					IKeyAndValue elementToMoveDown = parent.getKeyAndValueAt(childIndex);
					child.insertKeyAndValue(elementToMoveDown.getKey(), elementToMoveDown.getValue());
					child.mergeWith(rightSibling);
					parent.deleteKeyAndValueAt(childIndex, true);
					if (parent.getKeysCount() == 0) {
						// 根结点条件
						if (!parent.hasParent()) {
							root = child;
							root.setParent(null);
							height--;
							parentWasSetToNull = true;
						} else {
							throw new BTreeNodeValidationException("非根结点没有父结点!");
						}
					} else {
						parent.setChildAt(child, childIndex);
					}
					if (parentWasSetToNull) {
					} else {
						BTreeValidator.validateNode(parent, parent == root);
					}
					BTreeValidator.validateNode(child, child == root);
					if (parentWasSetToNull) {
						return root;
					}
					return parent;
				}
				throw new BTreeNodeValidationException("deleting case 3b but no non null sibling!");
			}
		} finally {
		}
		throw new BTreeNodeValidationException("prepareForDelete方法 发生不可欲知错误");
	}

	/**
	 * 插入数据
	 */
	public void insert(Comparable key, Object value) {
		// 根结点的关键字数量是否到达最大数量
		if (root.isFull()) {
			// 建立新的根结点
			INode newRoot = buildNode();
			INode oldRoot = root;
			newRoot.setChildAt(root, 0);
			newRoot.setChildrenCount(1);
			root = newRoot;
			split(newRoot, oldRoot, 0);
			height++;
			BTreeValidator.validateNode(newRoot, true);
		}
		//
		insertNonFull(root, key, value);
		size++;
	}

	/**
	 * 向结点插入键值对
	 * 
	 * @param node
	 * @param key
	 * @param value
	 */
	private void insertNonFull(INode node, Comparable key, Object value) {
		// 向叶子结点增加数据，插入后返回
		if (node.isLeaf()) {
			node.insertKeyAndValue(key, value);
			return;
		}

		// 获取在数组中的位置
		int position = node.getPositionOfKey(key);
		int realPosition = -position - 1;

		// 当前结点允许插入键值对，插入后返回
		if (position >= 0) {
			realPosition = position - 1;
			node.insertKeyAndValue(key, value);
			return;
		}

		// 获取合适的结点
		INode nodeToDescend = node.getChildAt(realPosition, true);

		// 如果该结点已经满了，需要分解
		if (nodeToDescend.isFull()) {
			split(node, nodeToDescend, realPosition);
			if (node.getKeyAt(realPosition).compareTo(key) < 0) {
				nodeToDescend = node.getChildAt(realPosition + 1, true);
			}
		}

		// 递归插入键值对
		insertNonFull(nodeToDescend, key, value);
	}

	/**
	 * 分解结点 
	 * 1获取结点中间的键值对
	 * 2 将该键值对插入父结点 (shifting necessary elements) 
	 * 3 创建新结点，并将原结点右边的键值对和孩子结点赋给该结点 
	 * 4 被分解结点作为父结点的子结点
	 */
	public void split(INode parent, INode node2Split, int childIndex) {
		// 1
		IKeyAndValue median = node2Split.getMedian();
		// 2
		parent.setKeyAndValueAt(median, childIndex, true, true);
		// 3
		INode rightPart = node2Split.extractRightPart();
		// 4
		parent.setChildAt(rightPart, childIndex + 1);
		parent.setChildAt(node2Split, childIndex);
		parent.incrementChildrenCount();
		if (BTreeValidator.isOn()) {
			BTreeValidator.validateNode(parent, parent == root);
			BTreeValidator.validateNode(rightPart, false);
			BTreeValidator.validateNode(node2Split, false);
		}
	}

	public int getSize() {
		return size;
	}

	public int getDegree() {
		return degree;
	}

	public INode getRoot() {
		return root;
	}

	public int getHeight() {
		return height;
	}

	public String getName() {
		return name;
	}

	public void clear() {
		root.clear();
	}

	public IKeyAndValue getBiggest(INode node, boolean delete) {
		int lastKeyIndex = node.getKeysCount() - 1;
		int lastChildIndex = node.getChildrenCount() - 1;
		if (lastChildIndex > lastKeyIndex) {
			INode child = node.getChildAt(lastChildIndex, true);
			if (child.getKeysCount() == degree - 1) {
				node = prepareForDelete(node, child, lastChildIndex);
			}
			lastChildIndex = node.getChildrenCount() - 1;
			child = node.getChildAt(lastChildIndex, true);
			return getBiggest(child, delete);
		}
		IKeyAndValue kav = node.getKeyAndValueAt(lastKeyIndex);
		if (delete) {
			node.deleteKeyAndValueAt(lastKeyIndex, false);
		}
		return kav;
	}

	public IKeyAndValue getSmallest(INode node, boolean delete) {
		if (!node.isLeaf()) {
			INode child = node.getChildAt(0, true);
			if (child.getKeysCount() == degree - 1) {
				node = prepareForDelete(node, child, 0);
			}
			child = node.getChildAt(0, true);
			return getSmallest(child, delete);
		}
		IKeyAndValue kav = node.getKeyAndValueAt(0);
		if (delete) {
			node.deleteKeyAndValueAt(0, true);
		}
		return kav;
	}
}
