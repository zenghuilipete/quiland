///*******************************************************************************************
// * oJadb is free software: you can redistribute it and/or modify it under 
// * the terms of the GNU General Public License as published by the Free Software Foundation, 
// * either version 3 of the License, or (at your option) any later version.
// * 
// * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
// * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// * See the GNU General Public License for more details.
// * 
// * You should have received a copy of the GNU General Public License along with this library. 
// * If not, see <http://www.gnu.org/licenses/>.
// * 
// * Author:EricHan
// * Time:2008-8-28
// ******************************************************************************************/
//package ojadb.core.btree.impl;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import ojadb.core.btree.IBTree;
//import ojadb.core.btree.IBTreePersister;
//import ojadb.core.btree.INode;
//
//public class MemoryPersister implements IBTreePersister{
//	public static final String LOG_ID = "MemoryPersister";
//	private Map<Long, INode> oids;
//	private List<Long> modifiedObjectOidList;
//	private IBTree tree;
//	private static Map<Long, INode> smap = null;
//	private static Map<Object, Integer> smodifiedObjects = null;
//	public static int nbSaveNodes = 0;
//	public static int nbSaveNodesInCache = 0;
//	public static int nbSaveTree = 0;
//	public static int nbLoadNodes = 0;
//	public static int nbLoadTree = 0;
//
//	public MemoryPersister() {
//		oids = new HashMap<Long, INode>();
//		modifiedObjectOidList = new ArrayList<Long>(500);
//		smap = oids;
//	}
//
//	public INode loadNodeById(Long id) {
//		return oids.get(id);
//	}
//
//	public Long saveNode(INode node) {
//		oids.put(node.getId(), node);
//		return node.getId();
//	}
//
//	public void close() throws Exception {
//		persist();
//	}
//
//	public Long saveBTree(IBTree treeToSave) {
//		tree = treeToSave;
//		return tree.getId();
//	}
//
//	public Long getNextNodeId() throws IOException {
//		return System.currentTimeMillis();
//	}
//
//	public void persist() {
//		return;
//	}
//
//	public void afterCommit() {
//	// nothing to do
//	}
//
//	public void beforeCommit() {
//		persist();
//		clear();
//	}
//
//	public INode deleteNode(INode object) {
//		oids.remove(object.getId());
//		return object;
//	}
//
//	public void setBTree(IBTree tree) {
//		this.tree = tree;
//	}
//
//	public static void resetCounters() {
//		nbSaveNodes = 0;
//		nbSaveTree = 0;
//		nbSaveNodesInCache = 0;
//		nbLoadNodes = 0;
//		nbLoadTree = 0;
//	}
//
//	public static StringBuffer counters() {
//		StringBuffer buffer = new StringBuffer("save nodes=").append(nbSaveNodes).append(" | save tree=").append(
//				nbSaveTree).append(" | loadNodes=").append(nbLoadNodes).append(" | load tree=").append(nbLoadTree);
//		if (smap != null && smodifiedObjects != null) {
//			buffer.append(" | map size=").append(smap.size()).append(" | modObjects size=").append(
//					smodifiedObjects.size());
//		}
//		return buffer;
//	}
//
//	public void clear() {
//		oids.clear();
//		modifiedObjectOidList.clear();
//	}
//
//	public void clearModified() {
//		modifiedObjectOidList.clear();
//	}
//
//	public void flush() {
//		persist();
//		clearModified();
//	}
//
//	public IBTree loadBTree(Long id) {
//		if (tree.getId() == id)
//			return tree;
//		return null;
//	}
// }