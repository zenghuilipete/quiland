/*******************************************************************************************
 * oJadb is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * either version 3 of the License, or (at your option) any later version.
 * 
 * oJadb is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this library. 
 * If not, see <http://www.gnu.org/licenses/>.
 * 
 * Author:EricHan
 * Time:2008-8-28
 ******************************************************************************************/
package ojadb.core.btree.impl;

import java.io.Serializable;
import ojadb.core.btree.IKeyAndValue;

public class KeyAndValue implements Serializable, IKeyAndValue {
	private static final long serialVersionUID = 612065480090530214L;
	private Comparable key;
	private Object value;

	public KeyAndValue(Comparable key, Object value) {
		this.key = key;
		this.value = value;
	}

	public String toString() {
		return new StringBuffer("(").append(key).append("=").append(value).append(") ").toString();
	}

	public Comparable getKey() {
		return key;
	}

	public void setKey(Comparable key) {
		this.key = key;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}