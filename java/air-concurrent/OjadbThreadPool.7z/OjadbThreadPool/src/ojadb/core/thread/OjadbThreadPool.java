package ojadb.core.thread;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class OjadbThreadPool {

    private int minimum;
    private int maximum;
    private LinkedBlockingQueue<OjadbThread> ojadbThreads;
    private BlockingQueue<OjadbTask> ojadbTasks;

    public OjadbThreadPool(int min, int max) throws OjadbException {
        if (0 < min && min < max) {
            minimum = min;
            maximum = max;
            ojadbThreads = new LinkedBlockingQueue<OjadbThread>();
            ojadbTasks = new LinkedBlockingQueue<OjadbTask>();
            for (int i = 0; i < minimum; i++) {
                OjadbThread worker = new OjadbThread(this, "worker" + i);
                worker.start();
            }
        } else {
            throw new OjadbException("无法建立线程池: 最小值必须大于零,小于最大值");
        }
    }

    void addWorker(OjadbThread ojadbThreadWorker) {
        ojadbThreads.offer(ojadbThreadWorker);
    }

    public void excute(OjadbTask thread) {
        // 生产任务
        ojadbTasks.offer(thread);

        OjadbThread worker = ojadbThreads.remove();
        if (worker != null) {
            worker.work();
        } else if (ojadbThreads.size() < maximum) {
            OjadbThread newWorker = new OjadbThread(this, "worker" + ojadbThreads.size());
            newWorker.start();
        } else {
        }
        releaseThreads();
    }

    private synchronized void releaseThreads() {
        while (ojadbThreads.size() > minimum) {
            OjadbThread worker = ojadbThreads.remove();

            if (worker != null) {
                System.out.println(worker + "is killed");
                worker.kill();
            }
        }
    }

    public synchronized OjadbTask getTask() {
        if (ojadbTasks.size() == 0) {
            return null;
        }
        // 消费任务
        return ojadbTasks.remove();
    }
}
