
package ojadb.core.thread;

/**
 *
 * @author luh
 */
public class OjadbException extends Exception {

    OjadbException(String message) {
        super(message);
    }

}
