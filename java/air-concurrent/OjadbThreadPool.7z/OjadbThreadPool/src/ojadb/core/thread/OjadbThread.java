package ojadb.core.thread;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class OjadbThread extends Thread {

    private AtomicBoolean isActived;
    private ReentrantLock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();
    private OjadbThreadPool pool;

    public OjadbThread(OjadbThreadPool pool, String threadName) {
        super(threadName);
        this.pool = pool;
        isActived = new AtomicBoolean(true);
    }

    @Override
    public synchronized void start() {
        super.start();
    }

    @Override
    public void run() {
        try {
            lock.lock();

            while (isActived.get()) {
                OjadbTask task = pool.getTask();
                if (task != null) {
                    try {
                        String result = (String) task.excute();
                        if (result.length() > 0) {
                            pool.addWorker(this);
                            // 懒工人策略 -- 没人招呼工作，绝不睡醒
                            condition.await();
                        }
                    } catch (Exception e) {
                    }
                } else {
                    pool.addWorker(this);
                    condition.await();
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void work() {
        try {
            lock.lock();
            condition.signal();
        } catch (Exception e) {
        } finally {
            lock.unlock();
        }
    }

    public void kill() {
        isActived.set(false);
        work();
    }

    @Override
    public String toString() {
        return getName();
    }
}
