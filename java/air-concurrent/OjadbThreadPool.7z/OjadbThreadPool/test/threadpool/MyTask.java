/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threadpool;

import ojadb.core.thread.OjadbTask;

/**
 *
 * @author luh
 */
class MyTask extends OjadbTask {

    public MyTask(String threadName) {
        super(threadName);
    }

    @Override
    public Object excute(){
        System.out.println("my task is excuting...");
        return super.excute();
    }

}
