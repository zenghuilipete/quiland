/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luh
 */

package threadpool;
  
import ojadb.core.thread.*;
import ojadb.core.thread.OjadbTask;

public class BasicTest {
    public static void main(String[] ojadbs) throws OjadbException {
        OjadbThreadPool pool = new OjadbThreadPool(5, 10);
        OjadbTask thread = new MyTask("test thread");
        pool.excute(thread);
        System.exit(0);
    }
}